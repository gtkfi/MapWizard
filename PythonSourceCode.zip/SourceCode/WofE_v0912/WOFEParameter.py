# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




import json
from json import JSONEncoder


class WOFEParameterWeights:
    def __init__(self, evidenceLayer: str, codeName: str, trainingSites: str, maskLayer: str,
                 wType: str, confidentContrast: float, unitArea: float,
                 workspace: str):
        self.evidenceLayer = evidenceLayer
        self.codeName = codeName
        self.trainingSites = trainingSites
        self.maskLayer = maskLayer
        self.wType = wType
        self.confidentContrast = confidentContrast
        self.unitArea = unitArea
        self.workspace = workspace

class WOFEParameterWeights2:
    def __init__(self, jsonfile):
        parameters = self.read_json(jsonfile)
        self.evidenceLayer = parameters.get('evidenceLayer')
        self.codeName = parameters.get('codeName')
        self.trainingSites = parameters.get('trainingSites')
        self.maskLayer = parameters.get('maskLayer')
        self.wType = parameters.get('wType')
        self.confidentContrast = parameters.get('confidentContrast')
        self.unitArea = parameters.get('unitArea')
        self.workspace = parameters.get('workspace')

    def read_json(self, JSONFileName):  
        with open(JSONFileName, 'r') as data_file:
            data = json.load(data_file)
        return data


class WOFEParameterResponse:
    def __init__(self, evidenceLayers, maskLayer: str, wtsTables,
                 trainingSites: str, unitArea: int, postProbRaster: str, stdDevRaster: str, 
                 mdVarianceRaster: str, totalStdDevRaster: str, confRaster: str, ndvRaster: str,
                 workspace: str):
        self.evidenceLayers = evidenceLayers
        self.maskLayer = maskLayer
        self.wtsTables = wtsTables
        self.trainingSites = trainingSites
        self.unitArea = unitArea
        self.postProbRaster = postProbRaster
        self.stdDevRaster = stdDevRaster
        self.mdVarianceRaster = mdVarianceRaster
        self.totalStdDevRaster = totalStdDevRaster
        self.confRaster = confRaster
        self.ndvRaster = ndvRaster
        self.workspace = workspace


class WOFEParameterResponse2:
    def __init__(self, jsonfile):
        parameters = self.read_json(jsonfile)
        self.evidenceLayers = parameters.get('evidenceLayers')
        self.maskLayer = parameters.get('maskLayer')
        self.wtsTables = parameters.get('wtsTables')
        self.trainingSites = parameters.get('trainingSites')
        self.unitArea = parameters.get('unitArea')
        self.postProbRaster = parameters.get('postProbRaster')
        self.stdDevRaster = parameters.get('stdDevRaster')
        self.confRaster = parameters.get('confRaster')
        self.ndvRaster = parameters.get('ndvRaster')
        self.workspace = parameters.get('workspace')

    def read_json(self, JSONFileName):
        with open(JSONFileName) as data_file:
            #data = data_file.read().replace('\n', '')
            data = json.load(data_file)
        return data

    def write_json(self, JSONFileName, Parameter):
        # Encode Param Object into JSON formatted Data using custom JSONEncoder
        JSONData = json.dumps(Parameter, indent=4, cls=ParamsEncoder)

        # Write string in JSON format to a json file:
        f = open(JSONFileName, "w")
        f.write(JSONData)
        f.close()

class WofeParameterWeightsValues:

    def __init__(self, wType, oid, classId, code, areaSqrKm, areaUnits, noPoints,
                 wPlus, sWPlus, wMinus, sWMinus, contrast, sContrast, studContrast,
                 genClass, weight, wStd):
    
        self.wType = wType
        self.oid = oid
        self.classId = classId
        self.code = code
        self.areaSqrKm = areaSqrKm
        self.areaUnits = areaUnits
        self.noPoints = noPoints
        self.wPlus = wPlus
        self.sWPlus = sWPlus
        self.wMinus = wMinus
        self.sWMinus = sWMinus
        self.contrast = contrast
        self.sContrast = sContrast
        self.studContrast = studContrast
        self.genClass = genClass
        self.weight = weight
        self.wStd = wStd
    

    def read_json(JSONFileName):
        with open(JSONFileName) as data_file:
            data = json.load(data_file)
        return data

    def write_json(JSONFileName, Parameter):
        # Encode Param Object into JSON formatted Data using custom JSONEncoder
        JSONData = json.dumps(Parameter, indent=4, cls=ParamsEncoder)

        # Write string in JSON format to a json file:
        f = open(JSONFileName, "w")
        f.write(JSONData)
        f.close()


# subclass JSONEncoder
class ParamsEncoder(JSONEncoder):

    def default(self, o):
        return o.__dict__
