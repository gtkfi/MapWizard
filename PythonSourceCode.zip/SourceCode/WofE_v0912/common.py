# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




def get_temp_name(prefix: str , workspace: str, filetype: str)->str:
    
    from os import walk
    
    i: int = 0
    name: str = prefix
    
    f = []
    for (dirpath, dirnames, filenames) in walk(workspace):
        f.extend(filenames)
        break
        
    exists: bool = True
    
    if filetype == "grid":
        while exists is True:
            i += 1
            if (name + str(i)) in dirnames:
                exists = True
            else: break
        ext = ''
    elif filetype == "tif" or filetype == "tiff":
        while exists is True:
            i += 1
            if (name + str(i)) + ".tif" in filenames:
                exists = True
            else: break
        ext = '.tif'    
    return name + str(i) + ext


def get_filename_without_extension(filename: str) -> str:
    import os
    return os.path.splitext(os.path.basename(filename))[0]


def get_file_extension(filename: str) -> str:
    import os
    return os.path.splitext(os.path.basename(filename))[1]

