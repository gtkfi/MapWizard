# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




import sys
try:
    import os
    import traceback
    import math
    import gdal, gdalconst
    import gisdataprocessing as gp
    import RasterProperties as rp
    import WOFEParameter as wp
    import polygonclipper as pc
    import ClassLogfile as CL
    from pathlib import Path
    import json
    import numpy
    
except Exception as e:
    print('Import failed ' + str(e))
    sys.exit(1)

# Calculate weights  
def calculate_weights(params: wp.WOFEParameterWeights, messages):
    
    evidenceLayer = params.evidenceLayer
    valueType = rp.get_raster_properties(params.evidenceLayer, 'VALUETYPE')
    codeName =  params.codeName
    trainingSites = params.trainingSites
    maskLayer = params.maskLayer
    Type = params.wType
    confidentContrast = params.confidentContrast
    unitArea = params.unitArea
    workspace = params.workspace
    
    if not os.path.exists(workspace):
        os.makedirs(workspace)

    # Set paths for logfile
    logger = CL.writelogfile('logfile.log', workspace)
    
    # Set paths for training sites
    tempTrainingSites = 'temp_' + os.path.basename(trainingSites)
    pathTrainingSites = os.path.dirname(trainingSites)
    
    # Set path for result jsonfile (for "response")
    ratParamsJsonName = os.path.basename(evidenceLayer).split('.')[0]
    jsonFilePath = os.path.join(os.path.abspath(workspace), ratParamsJsonName+".json") 
   
    # Copy layer  
    gp.copy_layer(trainingSites, 'temp_' + Path(trainingSites).stem, True)
    succ, mess = gp.get_value_by_location(evidenceLayer, os.path.join(pathTrainingSites, tempTrainingSites))
    if succ is not True:
        print(mess)
    else:
        print("okay")
       
    
    # Create the RAT
    try:
        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('OID', gdal.GFT_Integer, gdal.GFU_Generic)
        rat.CreateColumn("Count", gdalconst.GFT_Integer, gdalconst.GFU_Max)     
        rat.CreateColumn("Area", gdalconst.GFT_Real, gdalconst.GFU_Max)         
        rat.CreateColumn("AreaUnits", gdalconst.GFT_Real, gdalconst.GFU_Max)    
        rat.CreateColumn("CLASS", gdalconst.GFT_String, gdalconst.GFU_Generic)     
        if codeName != None and len(codeName) > 0:
            rat.CreateColumn("CODE", gdalconst.GFT_String, gdalconst.GFU_Generic)
        rat.CreateColumn("AREA_SQ_KM", gdalconst.GFT_Real, gdalconst.GFU_Max)   
        rat.CreateColumn("AREA_UNITS", gdalconst.GFT_Real, gdalconst.GFU_Max)   
        rat.CreateColumn("NO_POINTS", gdalconst.GFT_Integer, gdalconst.GFU_Max) 
        rat.CreateColumn("WPLUS", gdalconst.GFT_Real, gdalconst.GFU_Max)        
        rat.CreateColumn("S_WPLUS", gdalconst.GFT_Real, gdalconst.GFU_Generic)  
        rat.CreateColumn("WMINUS", gdalconst.GFT_Real, gdalconst.GFU_Min)       
        rat.CreateColumn("S_WMINUS", gdalconst.GFT_Real, gdalconst.GFU_Generic) 
        rat.CreateColumn("CONTRAST", gdalconst.GFT_Real, gdalconst.GFU_Generic) 
        rat.CreateColumn("S_CONTRAST", gdalconst.GFT_Real, gdalconst.GFU_Generic)
        rat.CreateColumn("STUD_CNT", gdalconst.GFT_Real, gdalconst.GFU_Generic) 
        rat.CreateColumn("GEN_CLASS", gdalconst.GFT_String, gdalconst.GFU_Generic)  
        rat.CreateColumn("WEIGHT", gdalconst.GFT_Real, gdalconst.GFU_Generic)   
        rat.CreateColumn("W_STD", gdalconst.GFT_Real, gdalconst.GFU_Generic) 
    except Exception as e:
        message = "Creating raster attribute table failed."
        print(message + str(e))
        logger.logger.error(message + str(e))
        sys.exit(1)

    # Filling the RAT (independent of A, C, D and U)
    #-----------------------------------------------
    try:
        # Cellsize of EvidenceLayer
        cellsizeEL = gp.get_cellsize(evidenceLayer)

        # Create maskraster from shapefile
        if maskLayer:
            maskLayerFileType = os.path.splitext(maskLayer)[1]#'.shp'
            maskTemp = os.path.join(os.path.abspath(workspace),"maskrasterfromshape1.tif")
            maskReclass = os.path.join(os.path.abspath(workspace),"reclassifiedmaskraster2.tif")
            evidenceLayerClipped = os.path.join(os.path.abspath(workspace),"clippedELinextent3.tif")
            evidenceLayerMasked = os.path.join(os.path.abspath(workspace),"maskedEL.tif")

            ndv0 = gp.get_nodatavalue(evidenceLayer)
            
            if maskLayerFileType == '.shp':
                pc.shape_to_raster(maskLayer, maskTemp, cellsizeEL)
                pc.set_null(maskTemp, maskReclass, ndv0)
                pc.clip(evidenceLayer, maskReclass, evidenceLayerClipped)
                pc.intersect(evidenceLayerClipped, maskReclass, ndv0, evidenceLayerMasked)
            else:  
                pc.set_null_rasmask(maskLayer, maskReclass, ndv0)
                pc.clip(evidenceLayer, maskReclass, evidenceLayerClipped)
                pc.intersect(evidenceLayerClipped, maskReclass, ndv0, evidenceLayerMasked)

            if os.path.exists(maskTemp): os.remove(maskTemp)
            if os.path.exists(maskReclass): os.remove(maskReclass)            
            if os.path.exists(evidenceLayerClipped): os.remove(evidenceLayerClipped)
            
        # Get the Values for classes and ndv
        if maskLayer:
            uniqueVals = gp.get_value_count(evidenceLayerMasked)[0]
            ndv = gp.get_nodatavalue(evidenceLayerMasked)
        else:
            uniqueVals = gp.get_value_count(evidenceLayer)[0]
            ndv = gp.get_nodatavalue(evidenceLayer)
                
        for i in uniqueVals: # a large negative nodata value would be on first position in the list, therefore numpy.roll to send it to the last position
            if i < 0:
                uniqueVals = numpy.roll(uniqueVals, -1)
                break
        #print(uniqueVals)
    
        rowcount = len(uniqueVals)
        
        # OID
        oid = gp.index_from_columnname(rat, "OID")#rat.SetValueAsInt(row, col, val)
        for i,j in enumerate(uniqueVals):
            rat.SetValueAsInt(i, oid, i+1)
        
        # CodeName
        if codeName != None and len(codeName) > 0:
            codeid = gp.index_from_columnname(rat, "CODE")
            for i in uniqueVals:
                rat.SetValueAsString(i, codeid, str(codeName)) 
    
        # Frequency of trainigpoints
        pointsonList = []
        if maskLayer:
            for i in uniqueVals:
                pointson = gp.get_feature_frequency_value(evidenceLayerMasked, os.path.join(pathTrainingSites, tempTrainingSites), i)
                pointsonList.append(pointson)
                #print(pointsonlist)
        else:
            for i in uniqueVals:
                pointson = gp.get_feature_frequency_value(evidenceLayer, os.path.join(pathTrainingSites, tempTrainingSites), i)
                pointsonList.append(pointson)
                #print(pointsonlist)
        
        totalpoints = sum(pointsonList[:-1])
        #print("totalpoints:",totalpoints)
        
        # Pixcount of EvidenceLayer
        pixcountlist = []
        #print(esrip.GetValueCount(maskedEvidenceLayer))
        if maskLayer:
            for i,j in enumerate(uniqueVals):
                pixcount = gp.get_value_count(evidenceLayerMasked)[1][i]
                pixcountlist.append(pixcount)
                #print(pixcountlist)
        else:
            for i,j in enumerate(uniqueVals):
                pixcount = gp.get_value_count(evidenceLayer)[1][i]
                pixcountlist.append(pixcount)
                #print(pixcountlist)
        
        for i in uniqueVals:
            if i < 0:
                pixcountlist.append(pixcountlist.pop(0)) #first index again to the end
        #print(pixcountlist)
        totalpix = sum(pixcountlist[:-1])
        
        # Area and AreaUnits
        areaList = []
        areaunitsList = []
        for i,j in enumerate(uniqueVals):
            area, areaunits = gp.calc_area_area_units(pixcountlist[i], cellsizeEL, unitArea)
            areaList.append(area)
            areaunitsList.append(areaunits)
        #print(areaList, areaunitsList)
        totalar, totalaru = gp.calc_area_area_units(totalpix, cellsizeEL, unitArea)

        

        # Filling the RAT depending on A, C, D and U
        #--------------------------------------------
        classid = gp.index_from_columnname(rat, "CLASS")
        areaid = gp.index_from_columnname(rat, "AREA_SQ_KM")
        areauid = gp.index_from_columnname(rat, "AREA_UNITS")
        frequencyid = gp.index_from_columnname(rat, "NO_POINTS")

        if Type == "Ascending":
            area0 = 0
            areaunits0 = 0
            pointson0 = 0
            for j,k in enumerate(uniqueVals):
                
                area0 += areaList[j]
                areaunits0 += areaunitsList[j]                   
                pointson0 += pointsonList[j]

                arAsc = [area0, totalar]
                aruAsc = [areaunits0, totalaru] 
                pointcountAsc = [pointson0, totalpoints]

                if uniqueVals[j] == int(ndv): 
                    rat.SetValueAsString(j, classid , 'NoData')        
                else:
                    rat.SetValueAsString(j, classid , str(uniqueVals[j]))        
                rat.SetValueAsDouble(j, areaid , arAsc[0])
                rat.SetValueAsDouble(j, areauid , aruAsc[0])
                rat.SetValueAsInt(j, frequencyid , pointcountAsc[0])

                if uniqueVals[j] == ndv: 
                    r = rowcount-1 
                    arndv = areaList[-1]
                    arundv = areaunitsList[-1]
                    pointsndv = pointsonList[-1]

                    rat.SetValueAsDouble(r, areaid , arndv)
                    rat.SetValueAsDouble(r, areauid , arundv)
                    rat.SetValueAsInt(r, frequencyid , pointsndv)
            
                #print(rat.GetValueAsInt(j, classid))                
                #print(rat.GetValueAsDouble(j, areaid))

        
        elif Type in ("Categorical", "Unique"):
            for j,k in enumerate(uniqueVals):
                
                arCU = [areaList[j], totalar - areaList[j]]
                aruCU = [areaunitsList[j], totalaru - areaunitsList[j]] 
                pointcountCU = [pointsonList[j], totalpoints - pointsonList[j]]

                if uniqueVals[j] == int(ndv): 
                    rat.SetValueAsString(j, classid , 'NoData')        
                else:
                    rat.SetValueAsString(j, classid , str(uniqueVals[j]))       
                rat.SetValueAsDouble(j, areaid , arCU[0])
                rat.SetValueAsDouble(j, areauid , aruCU[0]) 
                rat.SetValueAsInt(j, frequencyid , pointcountCU[0])

                if uniqueVals[j] == int(ndv): 
                    r = rowcount-1 
                    arndv = areaList[-1]
                    arundv = areaunitsList[-1]
                    pointsndv = pointsonList[-1]

                    rat.SetValueAsDouble(r, areaid , arndv)
                    rat.SetValueAsDouble(r, areauid , arundv)
                    rat.SetValueAsInt(r, frequencyid , pointsndv)

            logger.logger.info("Calculation of area, area units and number of points was successful. ")
            
        elif Type == "Descending":
            uniqueValsList = uniqueVals.tolist()
            uniqueValsReverseList = uniqueValsList[::-1] #reverse
            if uniqueVals[i] == int(ndv):
                uniqueValsReverseList.append(uniqueValsReverseList.pop(0)) #first index again to the end
            #print(uniquevalsreverselist)
            areaReverseList = areaList[::-1]
            if uniqueVals[i] == int(ndv):
                areaReverseList.append(areaReverseList.pop(0))
            #print(areareverselist)
            areaunitsReverseList = areaunitsList[::-1]
            if uniqueVals[i] == int(ndv):
                areaunitsReverseList.append(areaunitsReverseList.pop(0))
            
            pointsReverseList = pointsonList[::-1]
            if uniqueVals[i] == int(ndv):
                pointsReverseList.append(pointsReverseList.pop(0))
                
            area0 = 0
            areaunits0 = 0
            pointson0 = 0
            for j,k in enumerate(uniqueVals):
                
                area0 += areaReverseList[j]
                areaunits0 += areaunitsReverseList[j]
                pointson0 += pointsReverseList[j]

                arDesc = [area0 , totalar]
                aruDesc = [areaunits0, totalaru] 
                pointcountDesc = [pointson0, totalpoints]
                    
                if uniqueVals[j] == int(ndv): 
                    rat.SetValueAsString(j, classid , 'NoData')        
                else:
                    rat.SetValueAsString(j, classid , str(uniqueValsReverseList[j])) 
                rat.SetValueAsDouble(j, areaid , arDesc[0])
                rat.SetValueAsDouble(j, areauid , aruDesc[0])
                rat.SetValueAsInt(j, frequencyid , pointcountDesc[0]) 
                #print(rat.GetValueAsInt(j, classid)) 
                
                if uniqueVals[j] == int(ndv): 
                    r = rowcount-1 
                    arndv = areaList[-1]
                    arundv = areaunitsList[-1]
                    pointsndv = pointsonList[-1]

                    rat.SetValueAsDouble(r, areaid , arndv)
                    rat.SetValueAsDouble(r, areauid , arundv)
                    rat.SetValueAsInt(r, frequencyid , pointsndv)
            
            logger.logger.info("Calculation of area, area units and number of points was successful. ")

        else:
            logger.logger.warning("Type is not implemented. ")
           
        # Filling the RAT with WPLUS, WMINUS, CONTRAST, etc.
        #---------------------------------------------------
        WPid = gp.index_from_columnname(rat, "WPLUS")
        SPid = gp.index_from_columnname(rat, "S_WPLUS")
        WMid = gp.index_from_columnname(rat, "WMINUS")
        SMid = gp.index_from_columnname(rat, "S_WMINUS")
        Cid = gp.index_from_columnname(rat, "CONTRAST")
        SDCid = gp.index_from_columnname(rat, "S_CONTRAST")
        SCid = gp.index_from_columnname(rat, "STUD_CNT")

        unitArea = unitArea
        totalTPs = totalpoints
        totalArea = totalar
        #print("Unitarea", Unitarea)
        #print("totalTPs", totalTPs)
        #print("totalArea", totalArea)
        
        i = 0
        while i < rowcount:
            NO_POINTS = rat.GetValueAsInt(i, frequencyid)
            AREA_SQ_KM = rat.GetValueAsDouble(i, areaid)

            WP,SP,WM,SM,C,SDC,SC = make_wts(NO_POINTS, AREA_SQ_KM, unitArea, totalTPs, totalArea, Type)
            #print("AREA_SQ_K:", AREA_SQ_KM, "NO_POINTS:", NO_POINTS, "WP:", WP, "SP:", SP, "WM:", WM, "SM:", SM, "C:", C, "SDC:", SDC, "SC:", SC)
                    
            rat.SetValueAsDouble(i, WPid, WP)
            rat.SetValueAsDouble(i, SPid, SP)
            rat.SetValueAsDouble(i, WMid, WM)
            rat.SetValueAsDouble(i, SMid, SM)
            rat.SetValueAsDouble(i, Cid, C)
            rat.SetValueAsDouble(i, SDCid, SDC)
            rat.SetValueAsDouble(i, SCid, SC)
            
            if uniqueVals[i] == int(ndv): 
                r = rowcount-1 
                rat.SetValueAsDouble(r, WPid, 0.0)
                rat.SetValueAsDouble(r, SPid, 0.0)
                rat.SetValueAsDouble(r, WMid, 0.0)
                rat.SetValueAsDouble(r, SMid, 0.0)
                rat.SetValueAsDouble(r, Cid, 0.0)
                rat.SetValueAsDouble(r, SDCid, 0.0)
                rat.SetValueAsDouble(r, SCid, 0.0)

            i+=1
                        

        logger.logger.info("Calculation of WPlus, S_WPlus, WMinus, S_WMinus, Contrast, SD of Contrast and Studentized Contrast was successful. ")
    
    
        # Generalize table depending on A, C, D and U
        #--------------------------------------------
        gcid = gp.index_from_columnname(rat, "GEN_CLASS")
        weightid = gp.index_from_columnname(rat, "WEIGHT")
        wstdid = gp.index_from_columnname(rat, "W_STD")
        ndv = gp.get_nodatavalue(evidenceLayer)
        
        # Get max constrast and max stud_ctn:
        i = 0
        conts = []
        studconts = []
        while i < rowcount:
            cont = rat.GetValueAsDouble(i, Cid)
            conts.append(cont)
            studcont = rat.GetValueAsDouble(i, SCid)
            studconts.append(studcont)
            i+=1
        #maxcont = max(conts)
        #print("maxCONT:",maxcont)   
        #maxstudcont = max(studconts)    
        #print("maxsSTUD_CNT:",maxstudcont) 

        # Calculate gen_class, weight, and wstd
        if Type in ("Ascending", "Descending"):
            
            maxContrast = -9999999.0
            patNoTPs = 0
            patArea = 0.0
            maxOID = -1  

            i = 0
            while i < rowcount:
                if rat.GetValueAsString(i, classid) != 'NoData':
                    #print("i:",i)
                    #print("conts i:",conts[i])
                    #print("studconts i:",studconts[i])
                    if (conts[i] > maxContrast) and (studconts[i] >= confidentContrast):
                        maxContrast = conts[i]
                        maxOID = rat.GetValueAsInt(i, oid)
                        maxWplus = rat.GetValueAsDouble(i, WPid)
                        maxWplus_Std = rat.GetValueAsDouble(i, SPid)
                        maxWminus = rat.GetValueAsDouble(i, WMid)
                        maxWminus_Std = rat.GetValueAsDouble(i, SMid)
                        patNoTPs += rat.GetValueAsInt(i, frequencyid)
                        patArea += rat.GetValueAsDouble(i, areauid)
                          
                i+=1
                #print("maxOID", maxOID)
                #print("maxWplus", maxWplus)
                #print("maxWminus", maxWminus)
                
            if maxOID >= 0:
                i = 0
                while i < rowcount:
                            
                    if rat.GetValueAsInt(i, oid) <= maxOID:
                        if rat.GetValueAsString(i, classid) == 'NoData':
                            rat.SetValueAsString(i, gcid, 'NoData')
                            rat.SetValueAsDouble(i, weightid, 0.0)
                            rat.SetValueAsDouble(i, wstdid, 0.0)
                            #print(rat.GetValueAsInt(i, oid), rat.GetValueAsInt(i, gcid), rat.GetValueAsDouble(i, weightid), rat.GetValueAsDouble(i, wstdid))
                                
                        else:
                            rat.SetValueAsString(i, gcid, 2)
                            rat.SetValueAsDouble(i, weightid, maxWplus)
                            rat.SetValueAsDouble(i, wstdid, maxWplus_Std)
                            #print(rat.GetValueAsInt(i, oid), rat.GetValueAsInt(i, gcid), rat.GetValueAsDouble(i, weightid), rat.GetValueAsDouble(i, wstdid))
                                
                    i+=1

                i = 0
                while i < rowcount:

                    if rat.GetValueAsInt(i, oid) > maxOID:
                        if rat.GetValueAsString(i, classid) == 'NoData':
                            rat.SetValueAsString(i, gcid, 'NoData')
                            rat.SetValueAsDouble(i, weightid, 0.0)
                            rat.SetValueAsDouble(i, wstdid, 0.0)
                            #print(rat.GetValueAsInt(i, oid), rat.GetValueAsInt(i, gcid), rat.GetValueAsDouble(i, weightid), rat.GetValueAsDouble(i, wstdid))
                                
                        else:
                            rat.SetValueAsString(i, gcid, 1)
                            rat.SetValueAsDouble(i, weightid, maxWminus)
                            rat.SetValueAsDouble(i, wstdid, maxWminus_Std)
                            #print(rat.GetValueAsInt(i, oid), rat.GetValueAsInt(i, gcid), rat.GetValueAsDouble(i, weightid), rat.GetValueAsDouble(i, wstdid))
                                
                    i+=1
                                                   
            else:
                print("No contrast for the selected type satisfied the user defined confidence level. ")
                logger.logger.warning("No contrast for the selected type satisfied the user defined confidence level. ")
                logger.logger.warning("Table is incomplete. ")
        
        
        elif Type == "Categorical":
            Out_Area = 0
            Out_NumTPs = 0.0
            Out_Num = 0
            
            i = 0
            while i < rowcount:
                #print(studconts)
                #print((studconts[i] > (Confident_Contrast*-1)) and (studconts[i] < Confident_Contrast))
                if (studconts[i] > (confidentContrast*-1)) and (studconts[i] < confidentContrast):
                    Out_Gen_Class = int(99)
                    if uniqueVals[i] != ndv:
                        if rat.GetValueAsInt(i, classid) >= Out_Gen_Class:
                            Out_Gen_Class += 100
                        Out_NumTPs += rat.GetValueAsInt(i, frequencyid)
                        Out_Area += rat.GetValueAsDouble(i, areaid)
                        Out_Num += 1
                i+=1
                    #print(Out_Gen_Class)
                    #print(Out_NumTPs, Out_Area, Out_Num) 
            
            if Out_Num > 0:
                if Out_NumTPs == 0: 
                    Out_NumTPs = 0.001
                Wts = make_wts(float(Out_NumTPs), Out_Area, unitArea, totalTPs, totalArea, Type)
                #print("Wts2:", Wts)
                if not Wts:
                    print("Weights calculation aborted. ")
                    logger.logger.error("Weights calculation aborted. ")
                    sys.exit(1)
                
                
            In_Num = 0
            i = 0
            while i < rowcount:
                if rat.GetValueAsString(i, classid) == 'NoData':
                    rat.SetValueAsString(i, gcid, 'NoData')
                    rat.SetValueAsDouble(i, weightid, 0.0)
                    rat.SetValueAsDouble(i, wstdid, 0.0)
                    #print(rat.GetValueAsInt(i, oid), rat.GetValueAsInt(i, gcid), rat.GetValueAsDouble(i, weightid), rat.GetValueAsDouble(i, wstdid))
                
                elif abs(studconts[i]) >= confidentContrast:
                    rat.SetValueAsString(i, gcid, rat.GetValueAsString(i, classid))
                    rat.SetValueAsDouble(i, weightid, rat.GetValueAsDouble(i, WPid))
                    rat.SetValueAsDouble(i, wstdid, rat.GetValueAsDouble(i, SPid))
                    #print(rat.GetValueAsInt(i, oid), rat.GetValueAsInt(i, gcid), rat.GetValueAsDouble(i, weightid), rat.GetValueAsDouble(i, wstdid))
                    In_Num += 1
                
                elif Out_Num > 0:
                    if int(rat.GetValueAsString(i, classid)) == Out_Gen_Class:
                        print("Categorical: Class value of the outside generalized class is same as an inside class. ")
                        logger.logger.error("Categorical: Class value of the outside generalized class is same as an inside class. ")
                        sys.exit(1)
                    rat.SetValueAsString(i, gcid, str(Out_Gen_Class))
                    rat.SetValueAsDouble(i, weightid, Wts[2])
                    rat.SetValueAsDouble(i, wstdid, Wts[3])                        
                    #print(rat.GetValueAsInt(i, oid), rat.GetValueAsInt(i, gcid), rat.GetValueAsDouble(i, weightid), rat.GetValueAsDouble(i, wstdid))
                i+=1
            
            if In_Num == 0:
                print("No row contrast for the selected type satisfied the user confidence contrast. ")
                logger.logger.warning("No row contrast for the selected type satisfied the user confidence contrast. ")
                logger.logger.warning("Table is incomplete. ")
    
        #Type is Unique
        else: 
            i = 0
            while i < rowcount:
                rat.SetValueAsString(i, gcid, rat.GetValueAsString(i, classid))
                rat.SetValueAsDouble(i, weightid, 0.0)
                rat.SetValueAsDouble(i, wstdid, 0.0)
                #print(rat.GetValueAsInt(i, gcid), rat.GetValueAsDouble(i, weightid), rat.GetValueAsDouble(i, wstdid))
                i+=1
        
        #print("Calculation finished. ")
        logger.logger.info("Calculation finished. ")

    except Exception as e:
        message = "Filling the weights table failed. "
        print(message + str(e))
        logger.logger.error(message + str(e))
        sys.exit(1)  
    

    #Write JSON file: 
    try:
        Parameter = []
        if codeName != None and len(codeName) > 0:
            for i in range(len(uniqueVals)):
                p = wp.WofeParameterWeightsValues(Type,
                    rat.GetValueAsString(i, oid), rat.GetValueAsString(i, classid), rat.GetValueAsString(i, codeid), 
                    rat.GetValueAsString(i, areaid), rat.GetValueAsString(i, areauid), rat.GetValueAsString(i, frequencyid),
                    rat.GetValueAsString(i, WPid), rat.GetValueAsString(i, SPid), rat.GetValueAsString(i, WMid), rat.GetValueAsString(i, SMid),
                    rat.GetValueAsString(i, Cid), rat.GetValueAsString(i, SDCid), rat.GetValueAsString(i, SCid),
                    rat.GetValueAsString(i, gcid), rat.GetValueAsString(i,weightid), rat.GetValueAsString(i,wstdid))
                Parameter.append(p)
        else: 
            for i in range(len(uniqueVals)):
                p = wp.WofeParameterWeightsValues(Type,
                    rat.GetValueAsString(i, oid), rat.GetValueAsString(i, classid), "", 
                    rat.GetValueAsString(i, areaid), rat.GetValueAsString(i, areauid), rat.GetValueAsString(i, frequencyid),
                    rat.GetValueAsString(i, WPid), rat.GetValueAsString(i, SPid), rat.GetValueAsString(i, WMid), rat.GetValueAsString(i, SMid),
                    rat.GetValueAsString(i, Cid), rat.GetValueAsString(i, SDCid), rat.GetValueAsString(i, SCid),
                    rat.GetValueAsString(i, gcid), rat.GetValueAsString(i,weightid), rat.GetValueAsString(i,wstdid))
                Parameter.append(p)

        wp.WofeParameterWeightsValues.write_json(jsonFilePath, Parameter)
        #print("Results written to the json file. ")
        logger.logger.info("Results written to the json file. ")

        uniqueVals = None
        ndv = None

        return valueType
    
    except Exception as e:
        message = "Writing json failed."
        print(message + str(e))
        logger.logger.error(message + str(e))
        sys.exit(1)  

    



def make_wts(patternNTP, patternArea, unit, totalNTP, totalArea, Type):

    db = patternNTP
    ds = totalNTP
    s = totalArea/unit
    b = patternArea/unit
    
    #>>>>>>>>>>>> Traps
    #Traps and fixes for various acceptable data anomalies
    if db > ds: #Graeme's trap
        print('Input error: More than one TP per Unitcell in study area.')
        return tuple([0.0]*7)
    if Type == 'Categorical': # Categorical generalization
        if db == 0:
            return tuple([0.0]*7)
        elif db == ds:
            #As with issue #66 suggests - replaced with db -=.99:
            #db -= 0.01 # Won't work when s-b < ds-db 
            db -= 0.99
        elif db == 0.001:
            db = ds
            db -= 0.99
    else: # Ascending and Descending generalization
        if db == 0: #no accumulation
            return tuple([0.0]*7)
        elif db == ds: #Maximum accumulation
            db -= 0.99 # Won't work when s-b < ds-db
    # Fix b so can compute W- when db = MaxTPs
    if (s - b) <= (ds - db):  
        b = s + db - ds - 0.99
    # Warning if cannot compute W+
    if (b-db) <= 0.0:
        #fix pattern area if area less than unit size
        b = db + 1
        print('More than one TP per Unitcell in pattern.')
    #<<<<<<<<<<<<<<<<<<End of traps
        
    db = float(db)
    ds = float(ds)
        
    # Calculate W+
    # b-db can be negative or zero, but is trapped above
    pbd = db/ds
    pbdb = (b-db) / (s-ds)
    ls = pbd/pbdb
    wp = math.log(ls)

    # Calculate vp and sp
    # b-db can be negative, but is trapped above
    vp = (1.0 / db) + (1.0 / (b-db))
    sp = math.sqrt(vp)
        
    # Calculate W-
    # (s - b) <= (ds - db) creates negative arg to log
    # This inequality is trapped and fixed above
    pbbd = (ds-db) / ds
    pbbdb = (s-b-ds+db) / (s-ds)
    ln = pbbd / pbbdb
    wm = math.log(ln)

    # Calculate vm and sm        
    vm = (1.0 / (ds-db)) + (1.0 / (s-b-ds+db))
    sm = math.sqrt(vm)
        
    # Calculate Contrast
    c = wp - wm

    # Calculate Contrast Std Dev
    sdc = math.sqrt(vp+vm)

    # Studentized Contrast
    sc = c/sdc
    return (wp,sp,wm,sm,c,sdc,sc)
