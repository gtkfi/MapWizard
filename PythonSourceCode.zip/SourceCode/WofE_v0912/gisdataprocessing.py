# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




from osgeo import ogr
from osgeo import gdal
import numpy as np
import os
import traceback


def shape_to_raster(shapefile, outraster, cellsize): 
    ds = ogr.Open(shapefile)     #making the shapefile as an object.
    shp_layer = ds.GetLayer()    #getting layer information of shapefile.
    xmin, xmax, ymin, ymax = shp_layer.GetExtent()
    gdal.Rasterize(outraster, shapefile, xRes=cellsize, yRes=cellsize, burnValues=1, outputBounds=[xmin, ymin, xmax, ymax], outputType=gdal.GDT_Byte)

def replace_raster_values(inras, outras, valuetoreplace, replacevalue): 
    ds = gdal.Open(inras)
    band = ds.GetRasterBand(1)
    bandarray = band.ReadAsArray()

    bandarray[bandarray == valuetoreplace] = replacevalue

    # create new file
    driver = gdal.GetDriverByName('GTiff')
    newfile = driver.Create(outras, ds.RasterXSize, ds.RasterYSize, 1)
    newfile.GetRasterBand(1).WriteArray(bandarray) 
    newfile.GetRasterBand(1).SetNoDataValue(replacevalue)
       
    # spatial reference
    proj = ds.GetProjection()
    georef = ds.GetGeoTransform()
    newfile.SetProjection(proj)
    newfile.SetGeoTransform(georef)

def copy_layer(infeature: str,outfeature: str, overwrite: bool):
    """
    Parameters
    ----------
    infeature : str
        Shapefile + Path with Extension
    outfeature : str
        Shapefile without Extension
    """
    driver = ogr.GetDriverByName('ESRI Shapefile')
    dataSource = driver.Open(infeature, 1) # 0 means read-only. 1 means writeable.
    layer = dataSource.GetLayer()
    if overwrite is True:
        dataSource.CopyLayer(layer, outfeature, ['OVERWRITE=YES'])
    else:
        dataSource.CopyLayer(layer, outfeature, ['OVERWRITE=NO'])
    dataSource = None


def calculate_area(infeature) -> float:
    areaSum: float = 0
    area: float
    fieldname: str = 'Area'
    fieldexists: bool = False
    driver = ogr.GetDriverByName("ESRI Shapefile")
    dataSource = driver.Open(infeature, 1)
    layer = dataSource.GetLayer()

    # check if field exists already
    schema = []
    layerdef = layer.GetLayerDefn()
    for n in range(layerdef.GetFieldCount()):
        fielddef = layerdef.GetFieldDefn(n)
        schema.append(fielddef.name)

    for n in schema:
        if n == fieldname:
            fieldexists = True

    if fieldexists is False:
        new_field = ogr.FieldDefn(fieldname, ogr.OFTReal)
        new_field.SetWidth(50)
        new_field.SetPrecision(20)
        layer.CreateField(new_field)

    for feature in layer:
        geom = feature.GetGeometryRef()
        area = geom.GetArea()
        feature.SetField(fieldname, area)
        layer.SetFeature(feature)
        areaSum += area

    dataSource = None
    return areaSum


def get_linear_units_name_fc(infeature) -> str:
    driver = ogr.GetDriverByName("ESRI Shapefile")
    dataSource = driver.Open(infeature, 1)
    layer = dataSource.GetLayer()

    # from Layer
    spatialRef = layer.GetSpatialRef()
    unitname = spatialRef.GetLinearUnitsName()
    dataSource = None
    return unitname

def get_linear_units_name_ras(inras) -> str:
    
    dataSource = gdal.Open(inras)
    projstring = dataSource.GetProjection()
    if 'metre' in projstring:
        unitname = 'metre'
    dataSource = None
    return unitname

def raster_to_array(inraster):
    raster = gdal.Open(inraster)
    band = raster.GetRasterBand(1)
    array = band.ReadAsArray()
    return array


def array_to_raster(array, outraster: str, templateRaster: str):
    try:
        if os.path.exists(outraster):
            os.remove(outraster)

        type = os.path.splitext(os.path.basename(outraster))[1]
    
        ndv = get_nodatavalue(templateRaster)
        proj, georef = get_projection(templateRaster)
    
        if type == ".tif" or type == ".tiff":
            format = "GTiff"
    
        driver = gdal.GetDriverByName(format)
        size = np.shape(array)
        dest_dataset = driver.Create(outraster, size[1], size[0], 1, gdal.GDT_Float32)  # outraster, cols of raster array, rows of raster array, band
        dest_dataset.GetRasterBand(1).SetNoDataValue(ndv)
        dest_dataset.SetProjection(proj)
        dest_dataset.SetGeoTransform(georef)
        dest_dataset.GetRasterBand(1).WriteArray(array)
        dest_dataset = None
   
        return True, None

    except Exception:
        message = traceback.format_exc()
        return False, message

def array_to_raster2(array, outraster: str, templateRaster: str, ndv: float):
    try:
        if os.path.exists(outraster):
            os.remove(outraster)

        type = os.path.splitext(os.path.basename(outraster))[1]
        proj, georef = get_projection(templateRaster)

        if type == ".tif" or type == ".tiff":
            format = "GTiff"

        driver = gdal.GetDriverByName(format)
        size = np.shape(array)
        dest_dataset = driver.Create(outraster, size[1], size[0], 1, gdal.GDT_Float32)  # outraster, cols of raster array, rows of raster array, band
        dest_dataset.GetRasterBand(1).SetNoDataValue(ndv)
        dest_dataset.SetProjection(proj)
        dest_dataset.SetGeoTransform(georef)
        dest_dataset.GetRasterBand(1).WriteArray(array)
        dest_dataset = None

        return True, None

    except Exception:
        message = traceback.format_exc()
        return False, message


def get_nodatavalue(inraster):
    raster = gdal.Open(inraster)
    band = raster.GetRasterBand(1)
    return band.GetNoDataValue()


def get_projection(inraster):
    raster = gdal.Open(inraster)
    proj = raster.GetProjection()
    georef = raster.GetGeoTransform()
    return proj, georef


def get_value_count(inraster):
    array = raster_to_array(inraster)
    unique, counts = np.unique(array, return_counts=True)
    return unique, counts, dict(zip(unique, counts))


def get_value_by_location(inraster: str, infeature: str):
    print('GetValueByLocation')
    print(inraster)
    print(infeature)

    try:
        raster = gdal.Open(inraster)
        geotransform = raster.GetGeoTransform()
        originX = geotransform[0]
        originY = geotransform[3]
        pixelWidth = abs(geotransform[1])
        pixelHeight = abs(geotransform[5])
        cols = raster.RasterXSize
        rows = raster.RasterYSize
        ndv = get_nodatavalue(inraster)

        array = raster_to_array(inraster)

        x0 = originX + pixelWidth/2
        y0 = (originY + pixelHeight/2) - (rows*pixelHeight)

        fieldname = "Value"
        driver = ogr.GetDriverByName('ESRI Shapefile')
        dataSource = driver.Open(infeature, 1)  # 0 means read-only. 1 means writeable.

        layer = dataSource.GetLayer()
        field_name = ogr.FieldDefn(fieldname, ogr.OFTReal)
        field_name.SetWidth(50)
        field_name.SetPrecision(5)
        layer.CreateField(field_name)

        for feat in layer:
            geom = feat.GetGeometryRef()

            x = geom.GetX(0)
            y = geom.GetY(0)

            i = round((x-x0)/pixelWidth)
            j = round((y-y0)/pixelHeight)

            if i >= 0 and i <= cols and j <= rows and j >= 0:
                value = array[rows-j, i]

                if value != ndv:
                    feat.SetField(fieldname, np.double(value))
                    layer.SetFeature(feat)
                else:
                    feat.SetField(fieldname, -9999.9)
                    layer.SetFeature(feat)
            else:
                feat.SetField(fieldname, -9999.9)
                layer.SetFeature(feat)

        return True, "successfull completed"
    except Exception:
        message = traceback.format_exc()
        return False, message
    finally:
        dataSource = None


def get_count_by_location(inraster, infeature):
    raster = gdal.Open(inraster)
    geotransform = raster.GetGeoTransform()
    originX = geotransform[0]
    originY = geotransform[3]
    pixelWidth = abs(geotransform[1])
    pixelHeight = abs(geotransform[5])
    cols = raster.RasterXSize
    rows = raster.RasterYSize

    ndv = get_nodatavalue(inraster)
    array = raster_to_array(inraster)

    x0 = originX + pixelWidth/2
    y0 = (originY + pixelHeight/2) - (rows*pixelHeight)

    driver = ogr.GetDriverByName('ESRI Shapefile')
    dataSource = driver.Open(infeature, 0)  # 0 means read-only. 1 means writeable.
    layer = dataSource.GetLayer()

    countZero = 0
    countOne = 0

    for feat in layer:
        geom = feat.GetGeometryRef()

        x = geom.GetX(0)
        y = geom.GetY(0)

        i = round((x-x0)/pixelWidth)
        j = round((y-y0)/pixelHeight)

        if i >= 0 and i <= cols and j <= rows and j >= 0:  
            value = array[rows-j, i]

            if value == ndv:continue
            if value == 0: countZero += 1
            if value == 1: countOne += 1

            #xi=x0 + i * pixelWidth #:x-Coordinate of the raster cell
            #yi=y0 + j * pixelHeight #:y-Coordinate of the raster cell

    return countOne, countZero


# Get feature count in binary inraster, with inraster as base area
def get_feature_frequency(inraster, infeature):
    raster = gdal.Open(inraster)
    geotransform = raster.GetGeoTransform()
    originX = geotransform[0]
    originY = geotransform[3]
    pixelWidth = abs(geotransform[1])
    pixelHeight = abs(geotransform[5])
    cols = raster.RasterXSize
    rows = raster.RasterYSize

    ndv = get_nodatavalue(inraster)
    array = raster_to_array(inraster)

    x0 = originX + pixelWidth/2
    y0 = (originY + pixelHeight/2) - (rows*pixelHeight)

    driver = ogr.GetDriverByName('ESRI Shapefile')
    dataSource = driver.Open(infeature, 0)  # 0 means read-only. 1 means writeable.
    layer = dataSource.GetLayer()

    countZero = 0
    countOne = 0
    countNDV = 0

    for feat in layer:
        geom = feat.GetGeometryRef()

        x = geom.GetX(0)
        y = geom.GetY(0)

        i = round((x-x0)/pixelWidth)
        j = round((y-y0)/pixelHeight)

        if i >= 0 and i <= cols and j <= rows and j >= 0:  # features, die außerhalb des Rasters liegen werden ignoriert
            value = array[rows-j, i]

            if value == ndv: countNDV += 1
            elif value == 0: countZero += 1
            elif value == 1: countOne += 1

    return countOne, countZero, countNDV

def get_feature_frequency_value(inraster, infeature, rasterval):
    raster = gdal.Open(inraster)
    geotransform = raster.GetGeoTransform()
    originX = geotransform[0]
    originY = geotransform[3]
    pixelWidth = abs(geotransform[1])
    pixelHeight = abs(geotransform[5])
    cols = raster.RasterXSize
    rows = raster.RasterYSize
    
    array = raster_to_array(inraster)
        
    x0 =  originX + pixelWidth/2
    y0 = (originY + pixelHeight/2) - (rows*pixelHeight)
      
    driver = ogr.GetDriverByName('ESRI Shapefile')
    dataSource = driver.Open(infeature, 0) # 0 means read-only. 1 means writeable.
    layer = dataSource.GetLayer()
    
    countrasterval = 0
    
    for feat in layer:
        geom = feat.GetGeometryRef()
        
        x = geom.GetX(0)
        y = geom.GetY(0)
                                 
        i = round((x-x0)/pixelWidth)
        j = round((y-y0)/pixelHeight)
        
        if i >= 0 and i <= cols and j <= rows and j >= 0: 
            value = array[rows-j,i]
                        
            if value == rasterval: countrasterval += 1
            
    return countrasterval

# Get features count in inraster, with inraster as base/mask area
def get_features_count(inraster, infeature):
    raster = gdal.Open(inraster)
    geotransform = raster.GetGeoTransform()
    originX = geotransform[0]
    originY = geotransform[3]
    pixelWidth = abs(geotransform[1])
    pixelHeight = abs(geotransform[5])
    cols = raster.RasterXSize
    rows = raster.RasterYSize

    ndv=get_nodatavalue(inraster)

    array = raster_to_array(inraster)

    x0 =  originX + pixelWidth/2
    y0 = (originY + pixelHeight/2) - (rows*pixelHeight)

    driver = ogr.GetDriverByName('ESRI Shapefile')
    dataSource = driver.Open(infeature, 0) # 0 means read-only. 1 means writeable.
    layer = dataSource.GetLayer()

    count=0
    countNDV=0

    for feat in layer:
        geom = feat.GetGeometryRef()

        x = geom.GetX(0)
        y = geom.GetY(0)

        i = round((x-x0)/pixelWidth)
        j = round((y-y0)/pixelHeight)

        if i >= 0 and i <= cols and j <= rows and j >= 0:  
            value = array[rows-j, i]

            if value == ndv: countNDV += 1
            else: count += 1

    return count, countNDV


# Area und areaunits
def calc_area_area_units(countofpix, cellsize, unitarea):
    area = (countofpix * cellsize**2)/1000000.0
    areaunits = area / unitarea
    return area, areaunits


# Get index of raster attribute column
def index_from_columnname(rats, colname):
    nameofcols = []
    colcount = rats.GetColumnCount()
    for j in range(colcount):
        nameofcol = rats.GetNameOfCol(j)
        nameofcols.append(nameofcol)
    for index, name in enumerate(nameofcols):
        if name == colname:
            rid = index
            break
    return rid


def get_cellsize(inraster):
    raster = gdal.Open(inraster)
    gt = raster.GetGeoTransform()
    cellsize = gt[1]
    return cellsize


def create_ndv_raster(inrasters, outraster):
    # create base array:
    raster_array = raster_to_array(inrasters[0])
    outraster_array = np.zeros((raster_array.shape[0], raster_array.shape[1]))
    ndv = get_nodatavalue(inrasters[0])

    for raster in inrasters:
        raster_array = raster_to_array(raster)
        ndv_raster = get_nodatavalue(raster)
        index = (raster_array == ndv_raster)
        outraster_array[index] = ndv

    array_to_raster(outraster_array, outraster, inrasters[0])


def check_spatial_reference(filelist):
    projList = []
    for fil in filelist:
        if fil.endswith(".shp"):
            driver = ogr.GetDriverByName("ESRI Shapefile")
            dataSource = driver.Open(fil, 0)
            layer = dataSource.GetLayer()
            srs = layer.GetSpatialRef()
            projShapefile = srs.ExportToWkt()
            #print(projShapefile[0:50])
            projList.append(projShapefile)
        else:
            rast = gdal.Open(fil)
            projRaster = rast.GetProjection()
            #print(projRaster[0:50])
            projList.append(projRaster)  
    
    for i in range(0, len(projList)-1):
        if projList[i] != projList[i+1]:
            check = 1
            break
        else:
            check = 0

    if check == 1:    
        return False, "Projection of input files does not fit. "
    elif check == 0:
        return True, ""