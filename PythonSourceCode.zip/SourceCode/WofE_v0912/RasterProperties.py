# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




import gdal

def get_raster_properties(inraster,propertyname):
    dataset = gdal.Open(inraster)
    band = dataset.GetRasterBand(1)
    
    if propertyname == 'VALUETYPE': 
        return gdal.GetDataTypeName(band.DataType)
    elif propertyname == 'CELLSIZEX':
        return gdal.GetDataTypeName(band.DataType)
