# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




from osgeo import gdal, ogr


def shape_to_raster(shapefile, outras, pixel_size): # creates a raster with zeros and ones
    ds = ogr.Open(shapefile)     #making the shapefile as an object.
    shp_layer = ds.GetLayer()    #getting layer information of shapefile.
    xmin, xmax, ymin, ymax = shp_layer.GetExtent()
    gdal.Rasterize(outras, shapefile, xRes=pixel_size, yRes=pixel_size, burnValues=1, outputBounds=[xmin, ymin, xmax, ymax], outputType=gdal.GDT_Byte)
        
def set_null(inras, outras, ndv): # refers to result of shape_to_raster, zeros become NoData
    ds = gdal.Open(inras)
    band = ds.GetRasterBand(1)
    bandarray = band.ReadAsArray()
    
    bandarray[bandarray == 0] = ndv
    
    # create new file
    driver = gdal.GetDriverByName('GTiff')
    newfile = driver.Create(outras, ds.RasterXSize, ds.RasterYSize, 1, gdal.GDT_Int32)
    newfile.GetRasterBand(1).WriteArray(bandarray) 
    newfile.GetRasterBand(1).SetNoDataValue(ndv)  
       
    # spatial reference
    proj = ds.GetProjection()
    georef = ds.GetGeoTransform()
    newfile.SetProjection(proj)
    newfile.SetGeoTransform(georef)    
    
def set_null_rasmask(inras, outras, ndv): 
    ds = gdal.Open(inras)
    band = ds.GetRasterBand(1)
    bandarray = band.ReadAsArray()
    
    bandarray[bandarray == ndv] = 0 
    bandarray[bandarray > 0] = 1
    bandarray[bandarray == 0] = ndv
    
    # create new file
    driver = gdal.GetDriverByName('GTiff')
    newfile = driver.Create(outras, ds.RasterXSize, ds.RasterYSize, 1, gdal.GDT_Int32)
    newfile.GetRasterBand(1).WriteArray(bandarray) 
    newfile.GetRasterBand(1).SetNoDataValue(ndv)  
       
    # spatial reference
    proj = ds.GetProjection()
    georef = ds.GetGeoTransform()
    newfile.SetProjection(proj)
    newfile.SetGeoTransform(georef)    
        
def clip(inras, maskras, outras): 
    mask = gdal.Open(maskras, gdal.GA_ReadOnly)
    inraster = gdal.Open(inras, gdal.GA_ReadOnly)

    maskGeoTransform = mask.GetGeoTransform()

    inrasProjection = inraster.GetProjectionRef()
    inrasGeoTransform = inraster.GetGeoTransform()
    
    # check if shapefile-mask is larger than evidence layer
    maskX = mask.RasterXSize
    maskY = mask.RasterYSize
    inrasX = inraster.RasterXSize
    inrasY = inraster.RasterYSize

    if maskX >= inrasX:
        maxx = inrasGeoTransform[0] + inrasGeoTransform[1] * inrasX
        minx = inrasGeoTransform[0]
    if maskY >= inrasY:
        miny = inrasGeoTransform[3] + inrasGeoTransform[5] * inrasY
        maxy = inrasGeoTransform[3]
    if maskX < inrasX:
        maxx = maskGeoTransform[0] + maskGeoTransform[1] * maskX
        minx = maskGeoTransform[0]
    if maskY < inrasY:
        miny = maskGeoTransform[3] + maskGeoTransform[5] * maskY
        maxy = maskGeoTransform[3]
    
    gdal.Translate(outras, inraster, format='GTiff', projWin=[minx,maxy,maxx,miny], outputSRS=inrasProjection)
    
def intersect(inras, maskras, ndv, outras): 
    inraster = gdal.Open(inras)
    inrasband = inraster.GetRasterBand(1)
    inrasbanda = inrasband.ReadAsArray()
        
    # create new file
    driver = gdal.GetDriverByName('GTiff')
    newfile = driver.Create(outras, inraster.RasterXSize, inraster.RasterYSize, 1, gdal.GDT_Int32)
    newfile.GetRasterBand(1).WriteArray(inrasbanda) 
    newfile.GetRasterBand(1).SetNoDataValue(ndv)  
       
    # spatial reference
    proj = inraster.GetProjection()
    georef = inraster.GetGeoTransform()
    newfile.SetProjection(proj)
    newfile.SetGeoTransform(georef)   
    