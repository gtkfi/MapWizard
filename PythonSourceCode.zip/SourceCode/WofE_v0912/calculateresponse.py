# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




import sys, os

import numpy as np
import traceback
import os
import WOFEParameter as wp
import polygonclipper as pc
import common as com
import ClassLogfile as CL
import gisdataprocessing as gp
import sys
import math



def extract_raster_by_mask(evidenceLayer, maskLayer, outRaster, cellsize, workspace):
    maskLayerFileType = os.path.splitext(maskLayer)[1]#'.shp'

    maskTemp = os.path.join(os.path.abspath(workspace),"maskrasterfromshape.tif")
    maskReclass = os.path.join(os.path.abspath(workspace),"reclassifiedmaskraster.tif")
    clippedEvidenceLayer = os.path.join(os.path.abspath(workspace),"clippedELinextent.tif")
    
    ndv = gp.get_nodatavalue(evidenceLayer)

    if maskLayerFileType == '.shp':
        pc.shape_to_raster(maskLayer, maskTemp, cellsize)
        pc.set_null(maskTemp, maskReclass, ndv)
        pc.clip(evidenceLayer, maskReclass, clippedEvidenceLayer)
        pc.intersect(clippedEvidenceLayer, maskReclass, ndv, outRaster)
    else:  
        pc.set_null_rasmask(maskLayer, maskReclass, ndv)
        pc.clip(evidenceLayer, maskReclass, clippedEvidenceLayer)
        pc.intersect(clippedEvidenceLayer, maskReclass, ndv, outRaster)
    
    return maskReclass

def calculate_response(parameters, messages):
    # Set Variables # EvidenceLayers, MaskFeatureLayer, Wts_Tables, TrainingSites, Unitarea, PostProbRaster, stdDevRaster, ConfRaster, NDVRaster, Workspace
    inputRasters = parameters.evidenceLayers
    maskLayer = parameters.maskLayer
    wtsTables = parameters.wtsTables
    trainingPoints = parameters.trainingSites
    #unitArea = parameters.unitArea
    postProbRaster = parameters.postProbRaster
    stdDevRaster = parameters.stdDevRaster
    confRaster = parameters.confRaster
    ndvRaster = parameters.ndvRaster
    workspace = parameters.workspace

    output_s = os.path.dirname(stdDevRaster)
    output_c = os.path.dirname(confRaster)
    output_p = os.path.dirname(postProbRaster)
    output_n = os.path.dirname(ndvRaster)
    if not os.path.exists(output_s):
        os.makedirs(output_s)
    if not os.path.exists(output_p):
        os.makedirs(output_p)
    if not os.path.exists(output_n):
        os.makedirs(output_n)
    if not os.path.exists(output_c):
        os.makedirs(output_c)

    try:
        # set logger:
        log = CL.writelogfile('logfile.log', workspace)
        
        # Get Raster Properties
        cellsize = gp.get_cellsize(inputRasters[0])
        
        maskRasterLayer = os.path.join(workspace,com.get_temp_name('mask',workspace,"tif"))
        tempNdvRaster = os.path.join(workspace,com.get_temp_name('tempNDV',workspace,"tif"))

        maskLayerFileType = os.path.splitext(maskLayer)[1]#'.shp'
        
        if maskLayerFileType == '.shp':
            gp.shape_to_raster(maskLayer,maskRasterLayer,cellsize)
            maskRasterLayer2 = os.path.join(workspace,com.get_temp_name('mask',workspace,"tif"))
            gp.replace_raster_values(maskRasterLayer, maskRasterLayer2, 0, 255)
        else:
            maskRasterLayer2 = os.path.join(workspace,com.get_temp_name('mask',workspace,"tif"))
            ndv = gp.get_nodatavalue(maskLayer)
            gp.replace_raster_values(maskLayer, maskRasterLayer2, ndv, 255)

        # Getting Study area in area and sq. kilometers
        if maskLayerFileType == '.shp':
            area = gp.calculate_area(maskLayer)
            unitname = gp.get_linear_units_name_fc(maskLayer)
        else:
            uniqueVals = gp.get_value_count(maskLayer)[0]
            for i in uniqueVals: 
                if i < 0:
                    uniqueVals = np.roll(uniqueVals, -1)
                    break
            pixcountlist = []
            for i,j in enumerate(uniqueVals):
                pixcount = gp.get_value_count(maskLayer)[1][i]
                pixcountlist.append(pixcount)
            for i in uniqueVals:
                if i < 0:
                    pixcountlist.append(pixcountlist.pop(0)) 
            totalpix = sum(pixcountlist[:-1])
            cellsizem = gp.get_cellsize(maskLayer)
            area = cellsizem*cellsizem*totalpix
            unitname = gp.get_linear_units_name_ras(maskLayer)
        
        if unitname =="metre":
            studyArea = area / 1000000 #Conversion to km^2
        else: raise SystemExit("Error: unitname " + unitname + " is not supported.")
        
        #Get number of training points within mask area
        count = gp.get_features_count(maskRasterLayer2, trainingPoints)[0]
        numTPs = count

        #Prior probability
        priorProb = float(numTPs) / studyArea 
        #print("# priorProb:" , str(priorProb))

        # Create weight raster from raster's associated weights table
        wtsRasters = []

        # Create a list of raster with ndv for the Missing Data Variance tool.
        rasterndvList = []

        # Get weights
        weights = []

        #for inputRaster in inputRasters:
        for j, inputRaster in enumerate(inputRasters):
            outputRasterName = os.path.splitext(os.path.basename(inputRaster))[0] + "_W"
            # Create _W raster
            outputRaster = com.get_temp_name(outputRasterName, parameters.workspace, 'tif')

            inputRasterClip = os.path.join(workspace, com.get_temp_name('mask_' + os.path.splitext(os.path.basename(inputRaster))[0], workspace , 'tif'))
            maskReclass = extract_raster_by_mask(inputRaster, maskLayer, inputRasterClip, cellsize, workspace)
            inputArray = gp.raster_to_array(inputRasterClip)
            inputArray = inputArray.astype('float64')

            # Get Weights
            jsonFile = wtsTables[j]
            weights = wp.WofeParameterWeightsValues.read_json(jsonFile)

            # Get distinct raster values
            rastervalues = np.unique(inputArray)
            # Delete ndv from rastervalue list
            ndv = gp.get_nodatavalue(inputRasterClip)
            rastervalueNew = np.delete(rastervalues, np.where(rastervalues == ndv)).astype('int32')

            for i in rastervalueNew:
                for w in weights:
                    if int(w.get('classId')) == i:
                        weight = float(w.get('weight'))
                        inputArray[inputArray == i] = weight
                        break
                    if str(w.get('classId')) != 'NoData':
                        if int(w.get('classId')) == i:
                            weight = float(w.get('weight'))
                            inputArray[inputArray == i] = weight
                            break
                    elif str(w.get('classId')) == 'NoData':    
                        weight = float(w.get('weight'))
                        inputArray[inputArray == i] = weight
                        break

            wtsRasters.append(inputArray)
            gp.array_to_raster2(inputArray,os.path.join(workspace,outputRaster), inputRasterClip, 255.0)
            
            if ndv in inputArray: 
                rasterndvList.append(inputRasterClip)

        # Post Logit Raster
        constant = math.log(priorProb/(1.0 - priorProb))

        arrayRasterSum = np.copy(wtsRasters[0])
        # Set ndv to nan
        ndvBase = gp.get_nodatavalue(inputRasters[0])
        arrayRasterSum[arrayRasterSum == ndvBase] = np.nan

        if len(wtsRasters) > 1:
            for i in range (1, len(wtsRasters)):
                arrayRasterSumPrevious = np.copy(arrayRasterSum)
            
                ndv = gp.get_nodatavalue(inputRasters[i])
                wtsRasters[i][wtsRasters[i] == ndv] = np.nan
            
                arrayRasterSum = arrayRasterSumPrevious + wtsRasters[i]
            
                index = (wtsRasters[i] == wtsRasters[i]) # get nan index
                index = np.invert(index)
                arrayRasterSum [index] = wtsRasters[i][index] # use value wtsRasters[i]
                
                index = (arrayRasterSum == arrayRasterSum)
                index = np.invert(index)
                arrayRasterSum[index] = arrayRasterSumPrevious[index]

        arrayPostLogit = constant + arrayRasterSum
        log.logger.info("Post Logit calculated successful.")
        
        # Get Post Probability Raster 
        arrayPostProb = (np.exp(arrayPostLogit) / (1 + np.exp(arrayPostLogit)))
        result, message = gp.array_to_raster2(arrayPostProb, postProbRaster, inputRasterClip, 255.0)
        if not result:
            log.logger.error(message)
            sys.exit(0)

        log.logger.info("Post probability calculated successfully.")

        # Create STD raster from raster's associated weights table
        stdRasters = []
        
        #for inputRaster in inputRasters:
        for j, inputRaster in enumerate(inputRasters):
            # Read and clip raster data
            inputRasterClip = os.path.join(workspace,com.get_temp_name('mask_' + os.path.splitext(os.path.basename(inputRaster))[0], workspace , 'tif'))
            extract_raster_by_mask(inputRaster, maskLayer, inputRasterClip, cellsize, workspace)
            inputArray = gp.raster_to_array(inputRasterClip)
            inputArray = inputArray.astype('float64')
            # Create raster names
            stdoutputrastername = os.path.splitext(os.path.basename(inputRaster))[0] + "_S"
            outputRaster = com.get_temp_name(stdoutputrastername, parameters.workspace, 'tif')

            # Get weights
            jsonFile = wtsTables[j]
            weights = wp.WofeParameterWeightsValues.read_json(jsonFile)

            for i in rastervalueNew:
                for w in weights:
                    if str(w.get('classId')) != 'NoData':
                        if int(w.get('classId')) == i:
                            wStd = float(w.get('wStd'))
                            inputArray[inputArray == i] = wStd
                            break
                    elif str(w.get('classId')) == 'NoData':    
                        wStd = float(w.get('wStd'))
                        inputArray[inputArray == i] = wStd
                        break
            
            stdRasters.append(inputArray)

        # Calculation Post Probability STD Rasters
        stdRasters[0][stdRasters[0] == ndvBase] = np.nan

        if len(stdRasters) > 1:
            arraySumSqr = np.square(stdRasters[0])

            for i in range(1, len(stdRasters)):
                arraySumSqrPrevious = np.copy(arraySumSqr)

                ndv = gp.get_nodatavalue(inputRasters[i])
                stdRasters[i][stdRasters[i] == ndv] = np.nan
                arraySumSqr = arraySumSqrPrevious + np.square(stdRasters[i])

                index = (stdRasters[i] == stdRasters[i]) # get nan index
                index = np.invert(index)
                arraySumSqr [index] = stdRasters[i][index] # use value wtsRasters[i]

                index = (arraySumSqr == arraySumSqr)
                index = np.invert(index)
                arraySumSqr[index] = arraySumSqrPrevious[index]

        if len(stdRasters) == 1:
            arrayPostProbStd = np.copy(stdRasters[0])
        else:
            constant = 1.0 / float(numTPs)
            arrayPostProbStd = (np.sqrt(np.square(arrayPostProb) * (constant + arraySumSqr)))

        
        gp.array_to_raster2(arrayPostProbStd, stdDevRaster, inputRasterClip, 255.0)
        log.logger.info("Standard deviation calculated successfully.")
        
        # Create confidence raster
        arrayConfidence = np.zeros((arrayPostProb.shape[0], arrayPostProb.shape[1]))
        index = (arrayPostProb == np.isnan)
        index = np.invert(index)
        arrayConfidence[index] = (arrayPostProb / arrayPostProbStd)[index]
        gp.array_to_raster2(arrayConfidence, confRaster, inputRasterClip, 255.0)
        log.logger.info("Confidence calculated successfully.")
        
        # Create ndv raster:
        gp.create_ndv_raster(inputRasters, tempNdvRaster)
        if maskLayerFileType != '.shp':
            pc.clip(tempNdvRaster, maskLayer, ndvRaster)
        else:
            pc.clip(tempNdvRaster, maskReclass, ndvRaster)
        log.logger.info("No data value mask calculated successfully.")
        
        print("Calculation successfully completed.")
        log.logger.info("Calculation successfully completed.")
        
    except:
        print(traceback.print_exc())
        log.logger.error(traceback.format_exc())
        sys.exit(0)
    
    finally:
        # remove files in workspace:
        filelist = os.listdir(workspace)
    
        for file in filelist:
            ext = os.path.splitext(file)[1]
            if ext != ".json" and ext != ".log":
                os.remove(os.path.join(workspace, file))

        # close error handlers:
        handlers = log.logger.handlers[:]

        for handler in handlers:
            handler.close()
            log.logger.removeHandler(handler)
    

