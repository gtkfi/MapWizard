# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




import calculateresponse as calcResp
import calculateweights as calcWeights
import WOFEParameter as wp
import ClassLogfile as CL
from pathlib import Path
import sys
import os
import gisdataprocessing as gp

try:
    #Path for proj
    projpath = str(Path().absolute())
    projpath += r'\proj'
    if os.path.exists(projpath):
        os.environ['PROJ_LIB'] = projpath
        print(projpath)
    else:
        os.environ['PROJ_LIB'] = os.path.dirname(sys.argv[0]) + r'\proj'  
        print(os.path.dirname(sys.argv[0]) + r'\proj')

    
    jsonFullFilePath = sys.argv[1]
    weightsOrResponse = sys.argv[2] 
    
    # select weights or response
    if weightsOrResponse == 'calcweights':
        wpW = wp.WOFEParameterWeights2(jsonFullFilePath)
            
        pathtolog = wpW.workspace
        if not os.path.exists(pathtolog):
            os.makedirs(pathtolog)
        
        logger = CL.writelogfile('logfile.log', pathtolog)

        # Check spatial reference of input files
        check1, message = gp.check_spatial_reference([wpW.evidenceLayer, wpW.trainingSites])
        if check1 is False:
            print(message)
            logger.logger.warning(message)
                
        calcWeights.calculate_weights(wpW, 'mess')
        sys.exit(0)

    elif weightsOrResponse == 'calcresponse':
    
        wpR = wp.WOFEParameterResponse2(jsonFullFilePath)
        calcResp.calculate_response(wpR, 'mess')
        sys.exit(0)
        
    else:
        message = "Error occurred while selecting calculate weights or response. "
        print(message)
        pathtolog = os.path.dirname(os.path.abspath(__file__))
        logger = CL.writelogfile('logfile.log', pathtolog)
        logger.logger.error(message)
        sys.exit(1)

    

except Exception as e:
    message = "Error in start program. "
    print(message + str(e))
    pathtolog = os.path.dirname(os.path.abspath(__file__))
    logger = CL.writelogfile('logfile.log', pathtolog)
    logger.logger.error(message + str(e))
    sys.exit(1)