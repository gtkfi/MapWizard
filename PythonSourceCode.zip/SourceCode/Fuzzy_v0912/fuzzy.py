# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




import sys
try:
    import gdal
    import gdalnumeric
    import numpy
    import os
    import osr
    import ClassLogfile as CL
except Exception as e:
    print('import failed ' + str(e))
    sys.exit(2)


filename = os.path.basename(__file__)

def write_Geotiff(numpyArray, out, pathToLog):  
    try:
        format = "GTiff"
        driver = gdal.GetDriverByName( format )
        h = numpy.shape(numpyArray)
        dest_dataset = driver.Create(out+'.tif' ,h[1], h[0], 1, gdal.GDT_Float32) 
        dest_dataset.GetRasterBand(1).WriteArray(numpyArray[:,:]) 
        dest_dataset.GetRasterBand(1).SetNoDataValue(-9999) 
        dest_dataset = None
    
    except Exception as e:
        print("Writing of Geotiff failed." + str(e))
        CL.writelogfile(filename, pathToLog)
        sys.exit(1)

# for the Fuzzy functions
def get_datasets(dataset, pathToLog):
    try:
        data = gdalnumeric.LoadFile(dataset)
        numpyArray = numpy.asarray(data)
        return numpyArray
    
    except Exception as e:
        print("Creating of array failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))
        sys.exit(1)    

# Fuzzy functions
def fuzzy_sum(inputRasterList, pathToLog): 
    try:
        dataList=[]
        # get first raster from list
        raster1 = get_datasets(inputRasterList[0], pathToLog)
        # define ndv value to nan
        nan = numpy.nan
        # define shape 2. and 3. dimension according to first raster
        rasterShape = numpy.shape(raster1)
        # create array (with ones), 1 is 1. dimension
        newArray = numpy.ones((1, rasterShape[0], rasterShape[1] ), dtype=numpy.float)
        # fill array
        for raster in inputRasterList:
            dataset = get_datasets(raster, pathToLog)
            # change dtype
            dataset = dataset.astype(numpy.float)
            ndvx = get_nodatavalue(raster)
            dataset[dataset == ndvx] = nan
            newArray = numpy.append(newArray, [dataset], axis=0) 
        
        # deleting of the first array of ones
        newArray = numpy.delete(newArray, 0, axis=0)
    
        #1. step: each raster: 1 - raster value
        subtraction = numpy.subtract(1, newArray)
        #print(subtraction)
        #2. step: product of step 1
        product = numpy.prod(subtraction,axis=0)
        
        #print(product)
        #3. step: 1 - step 2
        subtractionFinal = numpy.subtract(1, product)
        # set ndv back to -9999 which is used in write_Geotiff
        subtractionNan = numpy.nan_to_num(subtractionFinal, nan=-9999)
        #print(subtractionFinal)
        dataList = numpy.asarray(subtractionNan)
    
        return dataList
    
    except Exception as e:
        print("Calculating fuzzy algebraic sum failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))

def fuzzy_product(inputRasterList, pathToLog):
    try:
        dataList=[]
        raster1 = get_datasets(inputRasterList[0], pathToLog)
        
        nan = numpy.nan
                        
        rasterShape = numpy.shape(raster1) 
        newArray = numpy.ones((1, rasterShape[0], rasterShape[1] ), dtype=numpy.float) 
        
        for raster in inputRasterList:
            dataset = get_datasets(raster, pathToLog)
            dataset = dataset.astype(numpy.float)
            ndvx = get_nodatavalue(raster)
            dataset[dataset == ndvx] = nan
            newArray = numpy.append(newArray, [dataset], axis=0)  
            
        #print(newArray)
        newArray = numpy.delete(newArray, 0, axis=0) 
        product = numpy.prod(newArray, axis=0)
        
        productNan = numpy.nan_to_num(product, nan=-9999)
        #print(product)
        dataList = numpy.asarray(productNan)
    
        return dataList
    
    except Exception as e:
        print("Calculating fuzzy algebaraic product failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))

def fuzzy_gamma(inputRasterList, gamma, pathToLog):
    try:
        dataList=[]
        gamma = float(gamma)
        if gamma >= 0 and gamma <=1:
            fsum = fuzzy_sum(inputRasterList, pathToLog)
            fprod = fuzzy_product(inputRasterList, pathToLog)
            
            fsum[fsum == -9999] = numpy.nan
            fprod[fprod == -9999] = numpy.nan

            fsumg = numpy.float_power(numpy.abs(fsum), gamma)
            fprodg = numpy.float_power(numpy.abs(fprod), 1 - gamma)
            
            multiplication = numpy.multiply(fsumg, fprodg)
            multiplicationNan = numpy.nan_to_num(multiplication, nan=-9999)
            dataList = numpy.asarray(multiplicationNan)
            return dataList
        else:
            print("Gamma is between 0 and 1.")
    
    except Exception as e:
        print("Gamma operation failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))

def fuzzy_or(inputRasterList, pathToLog):
    try:   
        dataList=[]
        raster1 = get_datasets(inputRasterList[0], pathToLog)
        raster2 = get_datasets(inputRasterList[1], pathToLog)
        raster1 = raster1.astype(numpy.float)
        raster2 = raster2.astype(numpy.float)

        ndv0 = get_nodatavalue(inputRasterList[0])
        raster1[raster1 == ndv0] = numpy.nan
        ndv1 = get_nodatavalue(inputRasterList[1])
        raster2[raster2 == ndv1] = numpy.nan
    
        maxim = numpy.maximum(raster1,raster2)
        if len(inputRasterList) == 2:
            maximN = maxim
        else:
            for raster in inputRasterList[2:]:
                rasterN = get_datasets(raster, pathToLog)
                rasterN = rasterN.astype(numpy.float)
                ndvx = get_nodatavalue(raster)
                rasterN[rasterN == ndvx] = numpy.nan

                maximN = numpy.maximum(maxim,rasterN)
        
        maximNan = numpy.nan_to_num(maximN, nan=-9999)
        dataList = numpy.asarray(maximNan)
    
        return dataList

    except Exception as e:
        print("Calculating fuzzy OR failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))

def fuzzy_and(inputRasterList, pathToLog):
    try:    
        dataList=[]
        raster1 = get_datasets(inputRasterList[0], pathToLog)
        raster2 = get_datasets(inputRasterList[1], pathToLog)
        #print(raster1[0:1])
        #print(raster2[0:1])
        raster1 = raster1.astype(numpy.float)
        raster2 = raster2.astype(numpy.float)
        
        ndv0 = get_nodatavalue(inputRasterList[0])
        raster1[raster1 == ndv0] = numpy.nan
        ndv1 = get_nodatavalue(inputRasterList[1])
        raster2[raster2 == ndv1] = numpy.nan

        minim = numpy.minimum(raster1,raster2)
        if len(inputRasterList) == 2:
            minimN = minim
        else:
            for raster in inputRasterList[2:]:
                rasterN = get_datasets(raster, pathToLog)
                rasterN = rasterN.astype(numpy.float)
                #print(rasterN[0:1])
                ndvx = get_nodatavalue(raster)
                rasterN[rasterN == ndvx] = numpy.nan
                
                minimN = numpy.minimum(minim,rasterN)
                #print(multiplication[0:1])
        
        minimNan = numpy.nan_to_num(minimN, nan=-9999)
        dataList = numpy.asarray(minimNan)
    
        return dataList
    
    except Exception as e:
        print("Calculating fuzzy AND failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))
    
# get upper left corner and utm zone 
def projinfo(rasterDataset, pathToLog):
    try:
        dataset = gdal.Open(rasterDataset)
        ulx = str(dataset.GetGeoTransform()[0]) 
        uly = str(dataset.GetGeoTransform()[3])
        projection = dataset.GetProjection()
        spr = osr.SpatialReference(projection)
        if spr.IsProjected:
            try:
                utmzone = spr.GetAttrValue('projcs')[-3:-1]
                hemi = spr.GetAttrValue('projcs')[-1:]
            except Exception as e:
                print("Method GetAttrValue (osr.SpatialReference) failed.")
        else:
            utmzone = 'xxx'
            hemi = 'X'
            print('Data is not projected.')
    
        dsproj = dataset.GetProjection()
        dstrans = dataset.GetGeoTransform() 
        dsres = str(dstrans[1]) 
        
        if hemi =='N':
            infostring = 'map info = {UTM, 1.000,1.000,'+ulx+','+uly+','+dsres+','+dsres+','+utmzone+',North,WGS84,units=Meters}\n'
        elif hemi =='S':
            infostring = 'map info = {UTM, 1.000,1.000,'+ulx+','+uly+','+dsres+','+dsres+','+utmzone+',South,WGS84,units=Meters}\n' 
        else:
            infostring = 'map info = {UTM, 1.000,1.000,'+ulx+','+uly+','+dsres+','+dsres+','+'xxx'+',X,WGS84,units=Meters}\n'       
        return infostring, dsproj

    except Exception as e:
        print("Reading of projection failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))


def check_spatialreference(rasterList, pathToLog):
    try:
        raster0 = gdal.Open(rasterList[0])
        dstrans0 = raster0.GetGeoTransform()
        shp0 = numpy.shape(gdalnumeric.LoadFile(rasterList[0]))
        proj0 = raster0.GetProjection()

        for ras in rasterList[1:]:
            raster = gdal.Open(ras)
            dstrans = raster.GetGeoTransform()
            shp = numpy.shape(gdalnumeric.LoadFile(ras))
            proj = raster.GetProjection()
            mess = []
            if proj0 != proj:
                mess.append('Projection of input rasters does not fit. ')
            if dstrans0 != dstrans:
                mess.append('Transformation of input rasters does not fit. ')
            if shp0 != shp:
                mess.append('Number of columns and rows of input rasters does not fit. ')
        if len(mess)>0:
            return False, mess
        else:
            return True, ''
    except Exception as e:
        print("Function get_extent failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))

# processing results to single band Geotiffs
def processing_fuzzy(workspace, inrasterList, customname, fuzzyMethod, gmm, pathToLog):
    targetFullFilePath = os.path.join(workspace,customname+str(fuzzyMethod)) 
    
    if fuzzyMethod == "And":
        result1 = fuzzy_and(inrasterList, pathToLog)
    if fuzzyMethod == "Or":
        result1 = fuzzy_or(inrasterList, pathToLog)
    if fuzzyMethod == "Sum":
        result1 = fuzzy_sum(inrasterList, pathToLog)
    if fuzzyMethod == "Prod":
        result1 = fuzzy_product(inrasterList, pathToLog)
    if fuzzyMethod == "Gamma":
        result1 = fuzzy_gamma(inrasterList, gmm, pathToLog)
    
    write_Geotiff(result1, targetFullFilePath, pathToLog)
    post(inrasterList, targetFullFilePath, customname, pathToLog)

# set projection
def post(inrasterList, targetFullFilePath, customname, pathToLog):
    try:
        for raster in inrasterList:
            raster0 = raster
            break
        info, proj = projinfo(raster0, pathToLog)
        #print('info',info)
        #print('pz',proj)
        infosplit = info.split(',') 
        xol = float(infosplit[3])
        yol = float(infosplit[4])
        xpx = float(infosplit[5])
        ypx = 0-float(infosplit[6])
        xrot = 0
        yrot = 0
        
        raster1 = gdal.Open(targetFullFilePath + '.tif', gdal.GA_Update)
        # set spatial reference
        raster1.SetProjection(proj)
        # set Geotransform (x coordinate of top left corner, pixel width, rotation on x axis, y coordinate of top left corner, rotation on y axis, pixel height)
        raster1.SetGeoTransform((xol, xpx, xrot, yol, yrot, ypx)) # double bracketed!
        # set bandname
        #rasterband1 = raster1.GetRasterBand(1)
        #rasterband1.SetDescription(customname+fuzzytype)
        raster1 = None
    
    except Exception as e:
        print("Projection failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))

def get_nodatavalue(inraster):
    raster = gdal.Open(inraster)
    band = raster.GetRasterBand(1)
    return band.GetNoDataValue()