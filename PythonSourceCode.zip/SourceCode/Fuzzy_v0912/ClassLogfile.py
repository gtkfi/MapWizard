# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




import logging
import traceback

class writelogfile():
    def __init__(self, filename, targetlocation):
        self.filename = filename
        self.targetlocation = targetlocation
        self.logger = logging.getLogger(self.filename)
        self.logger.setLevel(logging.DEBUG)        
        fh = logging.FileHandler(self.targetlocation+r'\logfile.log', 'a')
        fh.setLevel(logging.DEBUG)
        self.logger.addHandler(fh)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        self.logger.addHandler(fh)
