# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




import sys
try:
    import gdal
    import os
    import osr
    import numpy
    import gdal_merge
    import ClassLogfile as CL
except Exception as e:
    print('import failed ' + str(e))
    sys.exit(2)


# filename for pathToLog 
filename = os.path.basename(__file__) 


def get_extent(dataset, pathToLog):
    try:
        cols = dataset.RasterXSize
        rows = dataset.RasterYSize
        transform = dataset.GetGeoTransform()
        minx = transform[0]
        maxx = transform[0] + cols * transform[1] + rows * transform[2]

        miny = transform[3] + cols * transform[4] + rows * transform[5]
        maxy = transform[3]

        return {
                "minX": str(minx), "maxX": str(maxx),
                "minY": str(miny), "maxY": str(maxy),
                "cols": str(cols), "rows": str(rows)
                }   
    
    except Exception as e:
        print("Get extent failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))

def create_tiles(minx, miny, maxx, maxy, n, pathToLog):
    try: 
        width = maxx - minx
        height = maxy - miny

        matrix = []

        for j in range(n, 0, -1):
            for i in range(0, n):

                ulx = minx + (width/n) * i # 10/5 * 1
                uly = miny + (height/n) * j # 10/5 * 1

                lrx = minx + (width/n) * (i + 1)
                lry = miny + (height/n) * (j - 1)
                matrix.append([[ulx, uly], [lrx, lry]])

        return matrix
    
    except Exception as e:
        print("Create tiles failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))


def split(outputFolderPath, inputFile, n, pathToLog): # resulting raster of shape n x n 
    try:
        targetFilename = os.path.basename(inputFile).split('.')[0]
        
        driver = gdal.GetDriverByName('GTiff')
        dataset = gdal.Open(inputFile)
        band = dataset.GetRasterBand(1)
        transform = dataset.GetGeoTransform()

        extent = get_extent(dataset, pathToLog)
        
        minx = float(extent["minX"])
        maxx = float(extent["maxX"])
        miny = float(extent["minY"])
        maxy = float(extent["maxY"])
        
        if not os.path.exists(outputFolderPath):
            os.makedirs(outputFolderPath)

        tiles = create_tiles(minx, miny, maxx, maxy, n, pathToLog)
        transform = dataset.GetGeoTransform()
        xOrigin = transform[0]
        yOrigin = transform[3]
        pixelWidth = transform[1]
        pixelHeight = -transform[5]

        tileNum = 0
        for tile in tiles:

            minx = tile[0][0]
            maxx = tile[1][0]
            miny = tile[1][1]
            maxy = tile[0][1]

            p1 = (minx, maxy)
            p2 = (maxx, miny)

            i1 = int((p1[0] - xOrigin) / pixelWidth)
            j1 = int((yOrigin - p1[1])  / pixelHeight)
            i2 = int((p2[0] - xOrigin) / pixelWidth)
            j2 = int((yOrigin - p2[1]) / pixelHeight)

            new_cols = i2-i1
            new_rows = j2-j1

            data = band.ReadAsArray(i1, j1, new_cols, new_rows)

            ndv = get_nodatavalue(inputFile)
            
            new_x = xOrigin + i1*pixelWidth
            new_y = yOrigin - j1*pixelHeight

            new_transform = (new_x, transform[1], transform[2], new_y, transform[4], transform[5])

            outputFileBasename = targetFilename + "_" + str(tileNum) + ".tif"
            outputFullFilePath = os.path.join(outputFolderPath, outputFileBasename)
            
            dst_ds = driver.Create(outputFullFilePath, new_cols, new_rows, 1, gdal.GDT_Float32)

            # writing output raster
            dst_ds.GetRasterBand(1).WriteArray( data )
            dst_ds.GetRasterBand(1).SetNoDataValue(ndv)

            tif_metadata = {
                "minX": str(minx), "maxX": str(maxx),
                "minY": str(miny), "maxY": str(maxy)
                }
            dst_ds.SetMetadata(tif_metadata)

            # setting extension of output raster # top left x, w-e pixel resolution, rotation, top left y, rotation, n-s pixel resolution
            dst_ds.SetGeoTransform(new_transform)

            wkt = dataset.GetProjection()

            # setting spatial reference of output raster
            srs = osr.SpatialReference()
            srs.ImportFromWkt(wkt)
            dst_ds.SetProjection( srs.ExportToWkt() )

            dst_ds = None

            tileNum += 1

        dataset = None

    except Exception as e:
        print("Splitting failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))



# remerge after split using gdal_merge
def merger(origFolder, targetFullFilePath, pathToLog):
    
    try:
        argsList = ['', '-o', targetFullFilePath, '-n', '-9999', '-a_nodata', '-9999']
    
        # extend string list with input files
        for (path, dirnames, filenames) in os.walk(origFolder):
            argsList.extend(os.path.join(path, name) for name in filenames)
        #print(argsList)
        
        # call gdal_merge
        gdal_merge.main(argsList) 
    
    except Exception as e:
        print("gdal_merge failed." + str(e))
        logger = CL.writelogfile(filename, pathToLog)
        logger.logger.error(str(e))


def get_nodatavalue(inraster):
    raster = gdal.Open(inraster)
    band = raster.GetRasterBand(1)
    return band.GetNoDataValue()