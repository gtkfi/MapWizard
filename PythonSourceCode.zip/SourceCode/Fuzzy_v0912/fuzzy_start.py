# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




import sys
try:
    import os
    import split_merge
    import fuzzy
    import ClassLogfile as CL
    import ClassFuzzy as CF
    from pathlib import Path
except Exception as e:
    print('import failed ' + str(e))
    sys.exit(2)
    

# Path for proj
projpath = str(Path().absolute())
projpath += r'\proj'
if os.path.exists(projpath):
    os.environ['PROJ_LIB'] = projpath
    print(projpath)
else:
    os.environ['PROJ_LIB'] = os.path.dirname(sys.argv[0]) + r'\proj'  
    print(os.path.dirname(sys.argv[0]) + r'\proj')


# following parameters are read from JSON:
# workspace = path to targetfolder
# rasters = list of at least 2 rasters []
# customFilename = a string the resulting file is named, e.g. "fuzzy1"
# splitNumber = '' and 1 no splitting, integer n > 1 splitting in n x n tiles for large rasters
# fuzzyMethod = "And" "Or" "Sum" "Prod" "Gamma"
# gam = gamma for method Gamma, float between 0 and 1

### JSON ###
#jsonFullFilePath = r"G:\...\FuzzyParameter112.json"
jsonFullFilePath = sys.argv[1]

try:
    f_object = CF.FuzzyParameter.ReadJSON(jsonFullFilePath)
    
    workspace = f_object.workspace  
    customFilename = f_object.customfilename
    splitNumber = f_object.splitnumber
    fuzzyMethod = f_object.method
    gam = f_object.gamma
    inputRasterList = f_object.rasters
    #print(workspace, customFilename, splitNumber, fuzzyMethod, gam, inputRasterList)
except Exception as e:
    print("CF.FuzzyParameter.ReadJSON failed." + str(e))
    CL.writelogfile('fuzzy_start', os.path.dirname(os.path.abspath(__file__))) # writes the logfile into the folder of Python files
    sys.exit(1)

if not os.path.exists(workspace):
    os.makedirs(workspace)

pathToLog = workspace 
filename = os.path.basename(__file__)
logger = CL.writelogfile(filename, pathToLog)

### Check spatial reference  and shape of input rasters ###
result, message = fuzzy.check_spatialreference(inputRasterList, pathToLog)
mess1 = 'Projection of input rasters does not fit. '
mess2 = 'Transformation of input rasters does not fit. '
mess3 = 'Number of columns and rows of input rasters does not fit. '
if mess1 in message: 
    logger.logger.warning(mess1)
if mess2 in message:
    logger.logger.warning(mess2)
if mess3 in message:
    logger.logger.error(mess3)
    sys.exit(1)
    
### Split ###
if splitNumber != "" and int(splitNumber) > 1:
    fuzzyTempFolder = os.path.join(workspace, "fuzzytemp")       
    splitFilesFolder = os.path.join(workspace, "splitted")
    
    # create folders
    if not os.path.exists(fuzzyTempFolder):
        os.makedirs(fuzzyTempFolder)
    if not os.path.exists(splitFilesFolder):
        os.makedirs(splitFilesFolder)

    # deleting temp. folder in case calculation aborted before reaching deleting temp. folder at the end
    if len(os.listdir(fuzzyTempFolder)) != 0:  
        for filenam in os.listdir(fuzzyTempFolder):
            os.remove(os.path.join(fuzzyTempFolder, filenam))
    if len(os.listdir(splitFilesFolder)) != 0:
        for filenam in os.listdir(splitFilesFolder):
            os.remove(os.path.join(splitFilesFolder, filenam))

    # call split function
    try:
        for aRaster in inputRasterList:
            split_merge.split(splitFilesFolder, aRaster, int(splitNumber), pathToLog)   

    except Exception as e:
        print("Splitting of rasters failed." + str(e))
        logger.logger.error(str(e))
        sys.exit(1)

    # listing of tiles
    inputRasterList1 = []
    for (path, dirnames, filenames) in os.walk(splitFilesFolder):
        inputRasterList1.extend(os.path.join(path, name) for name in filenames)
    
    nTiles = int(splitNumber)*int(splitNumber)
    nOrigFiles = int((len(filenames))/nTiles)
    print("number of tiles", nTiles)
    print("number of files", nOrigFiles)
    
    # double while-loop to match coincident tiles
    i = 0
    j = 0
    inputRasterList2 = []
    while j < nTiles:
        while i < nOrigFiles:
            inputRasterList2.append(inputRasterList1[i*nTiles+j])
            #print("i", i)
            i+=1
        #print(inputRasterList2)

        ### Fuzzy with splitting ###
        try:
            if len(inputRasterList2)>=2: # min. 2 rasters
                fuzzy.processing_fuzzy(workspace=fuzzyTempFolder, inrasterList=inputRasterList2, customname=customFilename+str(j), fuzzyMethod=fuzzyMethod, gmm=gam, pathToLog=pathToLog)
            else:
                print("Number of rasters has to be at least two.")

        except Exception as e:
            print("Calculating fuzzy logic failed." + str(e))
            logger.logger.error(str(e))
            sys.exit(1)

        i = 0 
        inputRasterList2 = [] 
        j+=1
        #print("j", j)
    print("Fuzzied.") 

else:
    ### Fuzzy without splitting ###
    try:
        if len(inputRasterList)>=2: # min. 2 rasters
            fuzzy.processing_fuzzy(workspace=workspace, inrasterList=inputRasterList, customname=customFilename, fuzzyMethod=fuzzyMethod, gmm=gam, pathToLog=pathToLog)    
        else:
            print("Number of rasters has to be at least two.")

    except Exception as e:
        print("Calculating fuzzy logic failed." + str(e))
        logger.logger.error(str(e))
        sys.exit(1)

### Remerge ###
if splitNumber != "" and int(splitNumber) > 1:
    try:
        finalfullfilepath = os.path.join(workspace, customFilename + fuzzyMethod)
        split_merge.merger(fuzzyTempFolder, finalfullfilepath, pathToLog)
          
    except Exception as e:
        print("Merging of rasters failed." + str(e))
        logger.logger.error(str(e))
        sys.exit(1) 
else:
    pass

### Deleting temp. folder ###
if splitNumber != "" and int(splitNumber) > 1:
    try:
        for filenam in os.listdir(fuzzyTempFolder):
            os.remove(os.path.join(fuzzyTempFolder, filenam))
        
        for filenam in os.listdir(splitFilesFolder): 
            os.remove(os.path.join(splitFilesFolder, filenam))

        os.rmdir(fuzzyTempFolder)
        os.rmdir(splitFilesFolder)

    except Exception as e:
        print("Deletion of temporary files failed." + str(e))
        logger.logger.warning(str(e))
         
else:
    pass

print("Finished")
logger.logger.info('Fuzzy calculation completed successfully. ')



sys.exit(0)