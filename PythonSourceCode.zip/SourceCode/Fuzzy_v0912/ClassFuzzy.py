# -*- coding: utf-8 -*-
""" 
Company: Beak Consultants GmbH | Am St. Niclas Schacht 13 | 09599 Freiberg | Germany
Authors: Peggy Hielscher, Andreas Kempe (andreas.kempe@beak.de)
Created: 09/12/2020
Licence:  GNU General Public License (GPL) 3
"""




import json
from json import JSONEncoder

       
class FuzzyParameter:
    def __init__(self, workspace, customfilename, splitnumber, method, gamma, rasters):
        self.workspace = workspace
        self.customfilename = customfilename
        self.splitnumber = splitnumber
        self.method = method
        self.gamma = gamma
        self.rasters = rasters
        
        
    def ReadJSON(JSONFileName):  
        with open(JSONFileName, 'r') as file:
            data = file.read().replace('\n', '')
        
        return FuzzyParameterDecoder(data)
    
    
    def WriteJSON(JSONFileName, workspace, customfilename, splitnumber, method, gamma, rasterList):    
        Parameter = FuzzyParameter(workspace, customfilename, splitnumber, method, gamma, rasterList)
       
        #Encode FuzzyParam Object into JSON formatted Data using custom JSONEncoder
        FuzzyJSONData = json.dumps(Parameter, indent=4, cls=FuzzyParamsEncoder)
            
        #Write string in JSON format to a json file: 
        f=open(JSONFileName,"w")
        f.write(FuzzyJSONData)
        f.close()
    
    
# subclass JSONEncoder
class FuzzyParamsEncoder(JSONEncoder):
    def default(self, o):
        return o.__dict__

class FuzzyParameterDecoder(object):
    def __init__(self,j):
        self.__dict__=json.loads(j)